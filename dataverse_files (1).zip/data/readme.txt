Files:
- dataset_context: contains description of the variable defitions and measurement procedures
- codebook: contains the variable descriptions for the training and validation data.
- train.survival.csv: dataset appropriate for training predicton model using survival analysis (Cox model).
- train.long.csv: dataset for training predicton model using mixed model.
- validation.survival.csv: external validation dataset for survival models.
- validation.long.csv: external validation dataset for mixed models.

For analysis scripts please refer to supplemental file in the publication by J.A. van den Brand et al PLOS One 2019.