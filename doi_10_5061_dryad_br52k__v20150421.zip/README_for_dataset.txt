article: PLOS one doi:
title:  Hepcidin-25 in diabetic chronic kidney disease is predictive for mortality and progression to end stage renal disease
authors: Martin Wagner, Damien R. Ashby, Caroline Kurtz, Ahsan Alam, Mark Busbridge, Ulrike Raff, Josef Zimmermann, Peter U. Heuschmann, Christoph Wanner, Lothar Schramm

the dataset for the article is in excel format in a compressed zip-folder; variable names are self-explaining.

for further details and explanations please contact Dr. Martin Wagner at wagner_m@ukw.de
 